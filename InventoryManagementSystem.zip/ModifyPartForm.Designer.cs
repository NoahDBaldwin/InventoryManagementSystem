﻿namespace C__Task
{
    partial class ModifyPartForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            modifyPartCancelButton = new Button();
            modifyPartSaveButton = new Button();
            modifyPartMachineIDTextBox = new TextBox();
            modifyPartMachineIDLabel = new Label();
            modifyPartMinTextBox = new TextBox();
            modifyPartMinLabel = new Label();
            modifyPartMaxTextBox = new TextBox();
            modifyPartMaxLabel = new Label();
            modifyPartPriceTextBox = new TextBox();
            modifyPartPriceLabel = new Label();
            modifyPartInventoryTextBox = new TextBox();
            modifyPartInventoryLabel = new Label();
            modifyPartNameTextBox = new TextBox();
            modifyPartNameLabel = new Label();
            modifyPartIDTextBox = new TextBox();
            modifyPartIDLabel = new Label();
            modifyPartOutsourcedRadio = new RadioButton();
            modifyPartInHouseRadio = new RadioButton();
            modifyPartTitleLabel = new Label();
            SuspendLayout();
            // 
            // modifyPartCancelButton
            // 
            modifyPartCancelButton.Location = new Point(443, 433);
            modifyPartCancelButton.Name = "modifyPartCancelButton";
            modifyPartCancelButton.Size = new Size(90, 44);
            modifyPartCancelButton.TabIndex = 37;
            modifyPartCancelButton.Text = "Cancel";
            modifyPartCancelButton.UseVisualStyleBackColor = true;
            modifyPartCancelButton.Click += modifyPartCancelButton_Click;
            // 
            // modifyPartSaveButton
            // 
            modifyPartSaveButton.Location = new Point(320, 433);
            modifyPartSaveButton.Name = "modifyPartSaveButton";
            modifyPartSaveButton.Size = new Size(90, 44);
            modifyPartSaveButton.TabIndex = 36;
            modifyPartSaveButton.Text = "Save";
            modifyPartSaveButton.UseVisualStyleBackColor = true;
            modifyPartSaveButton.Click += modifyPartSaveButton_Click;
            // 
            // modifyPartMachineIDTextBox
            // 
            modifyPartMachineIDTextBox.Location = new Point(186, 350);
            modifyPartMachineIDTextBox.Name = "modifyPartMachineIDTextBox";
            modifyPartMachineIDTextBox.Size = new Size(234, 30);
            modifyPartMachineIDTextBox.TabIndex = 35;
            // 
            // modifyPartMachineIDLabel
            // 
            modifyPartMachineIDLabel.AutoSize = true;
            modifyPartMachineIDLabel.Location = new Point(57, 353);
            modifyPartMachineIDLabel.Name = "modifyPartMachineIDLabel";
            modifyPartMachineIDLabel.Size = new Size(97, 23);
            modifyPartMachineIDLabel.TabIndex = 34;
            modifyPartMachineIDLabel.Text = "Machine ID";
            // 
            // modifyPartMinTextBox
            // 
            modifyPartMinTextBox.Location = new Point(415, 296);
            modifyPartMinTextBox.Name = "modifyPartMinTextBox";
            modifyPartMinTextBox.Size = new Size(118, 30);
            modifyPartMinTextBox.TabIndex = 33;
            // 
            // modifyPartMinLabel
            // 
            modifyPartMinLabel.AutoSize = true;
            modifyPartMinLabel.Location = new Point(341, 299);
            modifyPartMinLabel.Name = "modifyPartMinLabel";
            modifyPartMinLabel.Size = new Size(39, 23);
            modifyPartMinLabel.TabIndex = 32;
            modifyPartMinLabel.Text = "Min";
            // 
            // modifyPartMaxTextBox
            // 
            modifyPartMaxTextBox.Location = new Point(186, 296);
            modifyPartMaxTextBox.Name = "modifyPartMaxTextBox";
            modifyPartMaxTextBox.Size = new Size(117, 30);
            modifyPartMaxTextBox.TabIndex = 31;
            // 
            // modifyPartMaxLabel
            // 
            modifyPartMaxLabel.AutoSize = true;
            modifyPartMaxLabel.Location = new Point(112, 299);
            modifyPartMaxLabel.Name = "modifyPartMaxLabel";
            modifyPartMaxLabel.Size = new Size(42, 23);
            modifyPartMaxLabel.TabIndex = 30;
            modifyPartMaxLabel.Text = "Max";
            // 
            // modifyPartPriceTextBox
            // 
            modifyPartPriceTextBox.Location = new Point(186, 245);
            modifyPartPriceTextBox.Name = "modifyPartPriceTextBox";
            modifyPartPriceTextBox.Size = new Size(234, 30);
            modifyPartPriceTextBox.TabIndex = 29;
            // 
            // modifyPartPriceLabel
            // 
            modifyPartPriceLabel.AutoSize = true;
            modifyPartPriceLabel.Location = new Point(56, 248);
            modifyPartPriceLabel.Name = "modifyPartPriceLabel";
            modifyPartPriceLabel.Size = new Size(98, 23);
            modifyPartPriceLabel.TabIndex = 28;
            modifyPartPriceLabel.Text = "Price / Cost";
            // 
            // modifyPartInventoryTextBox
            // 
            modifyPartInventoryTextBox.Location = new Point(186, 196);
            modifyPartInventoryTextBox.Name = "modifyPartInventoryTextBox";
            modifyPartInventoryTextBox.Size = new Size(234, 30);
            modifyPartInventoryTextBox.TabIndex = 27;
            // 
            // modifyPartInventoryLabel
            // 
            modifyPartInventoryLabel.AutoSize = true;
            modifyPartInventoryLabel.Location = new Point(72, 199);
            modifyPartInventoryLabel.Name = "modifyPartInventoryLabel";
            modifyPartInventoryLabel.Size = new Size(82, 23);
            modifyPartInventoryLabel.TabIndex = 26;
            modifyPartInventoryLabel.Text = "Inventory";
            // 
            // modifyPartNameTextBox
            // 
            modifyPartNameTextBox.Location = new Point(186, 145);
            modifyPartNameTextBox.Name = "modifyPartNameTextBox";
            modifyPartNameTextBox.Size = new Size(234, 30);
            modifyPartNameTextBox.TabIndex = 25;
            // 
            // modifyPartNameLabel
            // 
            modifyPartNameLabel.AutoSize = true;
            modifyPartNameLabel.Location = new Point(98, 148);
            modifyPartNameLabel.Name = "modifyPartNameLabel";
            modifyPartNameLabel.Size = new Size(56, 23);
            modifyPartNameLabel.TabIndex = 24;
            modifyPartNameLabel.Text = "Name";
            // 
            // modifyPartIDTextBox
            // 
            modifyPartIDTextBox.Location = new Point(186, 96);
            modifyPartIDTextBox.Name = "modifyPartIDTextBox";
            modifyPartIDTextBox.ReadOnly = true;
            modifyPartIDTextBox.Size = new Size(234, 30);
            modifyPartIDTextBox.TabIndex = 23;
            // 
            // modifyPartIDLabel
            // 
            modifyPartIDLabel.AutoSize = true;
            modifyPartIDLabel.Location = new Point(127, 99);
            modifyPartIDLabel.Name = "modifyPartIDLabel";
            modifyPartIDLabel.Size = new Size(27, 23);
            modifyPartIDLabel.TabIndex = 22;
            modifyPartIDLabel.Text = "ID";
            // 
            // modifyPartOutsourcedRadio
            // 
            modifyPartOutsourcedRadio.AutoSize = true;
            modifyPartOutsourcedRadio.Location = new Point(341, 13);
            modifyPartOutsourcedRadio.Name = "modifyPartOutsourcedRadio";
            modifyPartOutsourcedRadio.Size = new Size(120, 27);
            modifyPartOutsourcedRadio.TabIndex = 21;
            modifyPartOutsourcedRadio.TabStop = true;
            modifyPartOutsourcedRadio.Text = "Outsourced";
            modifyPartOutsourcedRadio.UseVisualStyleBackColor = true;
            modifyPartOutsourcedRadio.CheckedChanged += modifyPartOutsourcedRadio_CheckedChanged;
            // 
            // modifyPartInHouseRadio
            // 
            modifyPartInHouseRadio.AutoSize = true;
            modifyPartInHouseRadio.Location = new Point(172, 13);
            modifyPartInHouseRadio.Name = "modifyPartInHouseRadio";
            modifyPartInHouseRadio.Size = new Size(101, 27);
            modifyPartInHouseRadio.TabIndex = 20;
            modifyPartInHouseRadio.TabStop = true;
            modifyPartInHouseRadio.Text = "In-House";
            modifyPartInHouseRadio.UseVisualStyleBackColor = true;
            modifyPartInHouseRadio.CheckedChanged += modifyPartInHouseRadio_CheckedChanged;
            // 
            // modifyPartTitleLabel
            // 
            modifyPartTitleLabel.AutoSize = true;
            modifyPartTitleLabel.Font = new Font("Segoe UI", 13F);
            modifyPartTitleLabel.Location = new Point(12, 9);
            modifyPartTitleLabel.Name = "modifyPartTitleLabel";
            modifyPartTitleLabel.Size = new Size(125, 30);
            modifyPartTitleLabel.TabIndex = 19;
            modifyPartTitleLabel.Text = "Modify Part";
            // 
            // ModifyPartForm
            // 
            AutoScaleDimensions = new SizeF(9F, 23F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(574, 516);
            Controls.Add(modifyPartCancelButton);
            Controls.Add(modifyPartSaveButton);
            Controls.Add(modifyPartMachineIDTextBox);
            Controls.Add(modifyPartMachineIDLabel);
            Controls.Add(modifyPartMinTextBox);
            Controls.Add(modifyPartMinLabel);
            Controls.Add(modifyPartMaxTextBox);
            Controls.Add(modifyPartMaxLabel);
            Controls.Add(modifyPartPriceTextBox);
            Controls.Add(modifyPartPriceLabel);
            Controls.Add(modifyPartInventoryTextBox);
            Controls.Add(modifyPartInventoryLabel);
            Controls.Add(modifyPartNameTextBox);
            Controls.Add(modifyPartNameLabel);
            Controls.Add(modifyPartIDTextBox);
            Controls.Add(modifyPartIDLabel);
            Controls.Add(modifyPartOutsourcedRadio);
            Controls.Add(modifyPartInHouseRadio);
            Controls.Add(modifyPartTitleLabel);
            Font = new Font("Segoe UI", 10F);
            Name = "ModifyPartForm";
            Text = "Part";
            Load += ModifyPartForm_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button modifyPartCancelButton;
        private Button modifyPartSaveButton;
        private TextBox modifyPartMachineIDTextBox;
        private Label modifyPartMachineIDLabel;
        private TextBox modifyPartMinTextBox;
        private Label modifyPartMinLabel;
        private TextBox modifyPartMaxTextBox;
        private Label modifyPartMaxLabel;
        private TextBox modifyPartPriceTextBox;
        private Label modifyPartPriceLabel;
        private TextBox modifyPartInventoryTextBox;
        private Label modifyPartInventoryLabel;
        private TextBox modifyPartNameTextBox;
        private Label modifyPartNameLabel;
        private TextBox modifyPartIDTextBox;
        private Label modifyPartIDLabel;
        private RadioButton modifyPartOutsourcedRadio;
        private RadioButton modifyPartInHouseRadio;
        private Label modifyPartTitleLabel;
    }
}